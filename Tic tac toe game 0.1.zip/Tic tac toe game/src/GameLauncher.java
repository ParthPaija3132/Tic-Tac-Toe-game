
public class GameLauncher {

	public static void main(String[] args) {
		TicTacToe ticTacToe = new TicTacToe();
		ticTacToe.startGame();

	}
}
